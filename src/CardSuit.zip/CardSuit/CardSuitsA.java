package CardSuit;

public enum CardSuitsA {
    CLUBS, DIAMONDS, HEARTS, SPADES
}
